﻿(function (define) {
	define(["jquery-original"], function () {
		return jQuery.noConflict(true); 
	});
}(myGlobalRequire.define));