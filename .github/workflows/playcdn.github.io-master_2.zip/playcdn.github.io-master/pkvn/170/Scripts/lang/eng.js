﻿(function (define) {
	define(function () {
		var lang = [];
		return lang;
	})
}(myGlobalRequire.define));